export class Orders {
    public oid : number;
    public ocid : number;
    public ovid : number;
    public wal_source : string;
    public omid : number;
    public ord_date : Date;
    public ord_quantity : number;
    public ord_billamount : number;
    public ord_status : string;
    public ord_comments : string;
    constructor() {
    }
}
