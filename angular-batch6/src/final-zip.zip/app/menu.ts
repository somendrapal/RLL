export class Menu {
    public mid : number;
    public mitem : string;
    public mprice: number;
    public mcalories : number;
    public mspeciality : string;
    constructor() {
    }
}